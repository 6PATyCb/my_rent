#!/bin/sh
java -jar my_rent-1.0.jar
